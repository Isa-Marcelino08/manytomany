package com.example.thafany.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.thafany.entities.Aluno;
import com.example.thafany.entities.Curso;
import com.example.thafany.services.CursoService;

import io.swagger.v3.oas.annotations.Operation;


@RestController
@RequestMapping("/cursos")
public class CursoController {
	
private final CursoService cursoService;
	
	public CursoController (CursoService cursoService) {
		this.cursoService = cursoService;
	} 
	
	@PostMapping("/salvar")
	@Operation(summary="Operação listar todos os alunos")
	public Curso createCurso(@RequestBody Curso curso) {
		return cursoService.insertCurso(curso);
	}
	
	@GetMapping("/{id}")
	public Curso getCursoById(@PathVariable Long id) {
		return cursoService.findCursoById(id);
	}
	
	@GetMapping("/listar")
	public List<Curso> getAllCursos(){
		return cursoService.findAllCursos();
	}
	
	@GetMapping("/curso-aluno/")
	public List<Curso> getCursoPorAluno(@RequestParam String nomeAluno){
		return cursoService.BuscarCursoPorAluno(nomeAluno);
	}

}
