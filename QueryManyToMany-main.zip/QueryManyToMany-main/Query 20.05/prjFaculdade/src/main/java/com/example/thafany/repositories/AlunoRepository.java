package com.example.thafany.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.thafany.entities.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Long>{
	
	@Query("SELECT a FROM Aluno a JOIN a.cursos c WHERE c.nameCurso = :nomeCurso")
	List<Aluno> findAlunoByCurso(@Param("nomeCurso") String nomeCurso);

	@Query("SELECT a FROM  Aluno a WHERE LOWER(a.nome) LIKE LOWER(CONCAT ('%',:nome,'%'))")
	List<Aluno> findByNomeContendo(@Param("nome") String nome); //um nome que contém... (ex: passos - vai selecionar tados as pessoas que tenha "passos" no nome) 
	
	@Query("SELECT a FROM Aluno a WHERE SIZE(a.cursos) > 1")
	List<Aluno> findAlunosComMaisDeUmCurso();
}
