package com.example.thafany.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.thafany.entities.Curso;
import com.example.thafany.repositories.CursoRepository;

@Service
public class CursoService {
	
private final CursoRepository cursoRepository;
	
	public CursoService(CursoRepository cursoRepository) {
		this.cursoRepository = cursoRepository;
	}
	
	public Curso findCursoById(Long id) {
		Optional<Curso> curso = cursoRepository.findById(id);
		return curso.orElse(null);
	}
	
	public Curso insertCurso(Curso curso) {
		return cursoRepository.save(curso);
	}
	
	public List<Curso> findAllCursos() {
		return cursoRepository.findAll();
	}
	
	public List<Curso> BuscarCursoPorAluno(String nomeAluno){
		return cursoRepository.findCursoByAluno(nomeAluno);
	}

}
