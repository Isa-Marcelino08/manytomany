package com.example.thafany.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.thafany.entities.Aluno;
import com.example.thafany.services.AlunoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name="Alunos", description = "API de Cadastro de Alunos")
@RestController
@RequestMapping("/alunos")
public class AlunoController {
	
	private final AlunoService alunoService;
	
	public AlunoController (AlunoService alunoService) {
		this.alunoService = alunoService;
	} 
	
	@PostMapping("/salvar")
	@Operation(summary="Operação para salvar aluno")
	public Aluno createAluno(@RequestBody Aluno aluno) {
		return alunoService.insertAluno(aluno);
	}
	
	@GetMapping("/{id}")
	@Operation(summary="Operação para buscar aluno por id")
	public Aluno getAlunoById(@PathVariable Long id) {
		return alunoService.findAlunoById(id);
	}
	
	@GetMapping("/listar")
	@Operation(summary="Operação listar todos os alunos")
	public List<Aluno> getAllAlunos(){
		return alunoService.findAllAlunos();	
	}
	
	@GetMapping("/alunos-curso/")
	@Operation(summary="Operação para listar aluno por curso")
	public List<Aluno> listarAlunoPorCurso(@RequestParam String nome){
		return alunoService.BuscaAlunoPorCurso(nome);
	}
	
	@GetMapping("/nome/")
	@Operation(summary="Operação listar aluno por nome contendo...")
	public List<Aluno> buscaPorNome(@RequestParam String nome){
		return alunoService.BuscarPorNomeContendo(nome);
	}
	
	@GetMapping("/multi-cursos/")
	@Operation(summary="Operação para listar alunos com mais de um Curso")
	public List<Aluno> buscaAlunoComMaisCurso(){
		return alunoService.BuscarAlunoComMaisDeUmCurso();
	}
	
	
}
